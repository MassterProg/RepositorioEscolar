import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carrera',
  templateUrl: './carrera.component.html',
  styleUrls: ['./carrera.component.css']
})
export class CarreraComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
